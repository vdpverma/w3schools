<?php
include "db.php";
 $id=$_GET['id'];
 $name=$_GET['name'];
 $type=$_GET['type'];

$sql = "UPDATE menu SET name='$name',type='$type' WHERE id='$id'";
if ($conn->query($sql) === TRUE) {
    echo "Record Updated successfully";
} else {
    echo "Error Updated record: " . $conn->error;
}


?>