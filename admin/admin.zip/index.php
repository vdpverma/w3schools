<?php
include "db.php";
if($_POST){
    
    $username=  $_POST['name'];
    $password=  $_POST['pwd'];
    
    
    $sql = "SELECT * FROM users where name='$username' and pwd='$password'";
    $result = $conn->query($sql);
    //count($result);
    $row = $result->fetch_assoc();
       echo $row["id"];
       echo $row["name"];
    if(!empty($row["id"]))
    {
		session_start();
		$_SESSION['adminid']= $row["id"];
        //echo  "welcome";
        header('Location: welcome.php');
    }
    else {
         
        echo  "Not authenced user";
    }
    
    
}
    
    
?>

<html>
<head>
</head>
<body>
<table align="center" width="500">
<form action="index.php" method="post">
<tr><td>User Name: <input type="text" name="name"></td></tr>
<tr><td>Password : <input type="text" name="pwd"></td></tr>
<tr><td><input type="submit" name="submit" value="submit"></td></tr>
</form>
</table>
</body>
</html>