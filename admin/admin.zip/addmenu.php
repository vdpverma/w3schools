<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "w3schools";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$name= $_POST['name'];
$type= $_POST['type'];
$sql = "INSERT INTO menu (name, type)
VALUES ('$name','$type')";

if ($conn->query($sql) === TRUE) {
    echo "New MENU addes record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

 header('Location: menu.php');

?>