<table width="700" align="center">

<tr bgcolor="#cccccc"><td><a href="ml.php">Menu List</a></td>
<td><a href="menu.php">ADD Menu</a></td>
<td><a href="page.php">ADD PAGES</a></td>
<td><a href="pl.php">Pages List</a></td>

<td><a href="logout.php">LOGOUT</a></td>


</tr>
</table>